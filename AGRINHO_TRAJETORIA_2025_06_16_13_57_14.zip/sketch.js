let pontosCampo = [];
let pontosCidade = [];
let linhas = [];
let animacoes = [];

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(255);

  // Desenhar a cidade
  fill(100, 100, 255);
  noStroke();
  ellipse(650, 150, 50, 50);  // Ponto na cidade
  fill(0); // Cor preta para o texto
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Cidade", 650, 120); // Texto acima da bolinha da cidade

  fill(100, 100, 255);
  ellipse(700, 200, 50, 50);  // Outro ponto na cidade
  fill(0); // Cor preta para o texto
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Cidade", 700, 170); // Texto acima da bolinha da cidade

  // Desenhar o campo
  fill(34, 139, 34);
  ellipse(150, 400, 50, 50);  // Ponto no campo
  fill(0); // Cor preta para o texto
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Campo", 150, 370); // Texto acima da bolinha do campo
  
  fill(34, 139, 34);
  ellipse(200, 450, 50, 50);  // Outro ponto no campo
  fill(0); // Cor preta para o texto
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Campo", 200, 420); // Texto acima da bolinha do campo
  
  // Desenhar as linhas entre o campo e a cidade
  stroke(0);
  strokeWeight(2);
  for (let linha of linhas) {
    line(linha[0].x, linha[0].y, linha[1].x, linha[1].y);
  }
  
  // Desenhar as animações
  for (let animacao of animacoes) {
    animacao.update();
    animacao.display();
  }
}

function mousePressed() {
  // Verificar se o clique é na cidade ou no campo
  if (mouseX > 600 && mouseX < 800 && mouseY < 300) {
    // Ponto na cidade
    pontosCidade.push(createVector(mouseX, mouseY));
  } else if (mouseX < 200 && mouseY > 300) {
    // Ponto no campo
    pontosCampo.push(createVector(mouseX, mouseY));
  }

  // Criar as conexões (pontes) entre os pontos
  if (pontosCampo.length > 0 && pontosCidade.length > 0) {
    // Criar uma linha entre o último ponto do campo e o último ponto da cidade
    let pontoCampo = pontosCampo[pontosCampo.length - 1];
    let pontoCidade = pontosCidade[pontosCidade.length - 1];
    linhas.push([pontoCampo, pontoCidade]);

    // Criar animação com base na conexão
    // Sempre que conectar o campo à cidade, ou vice-versa, aparecerá uma bolinha roxa
    animacoes.push(new Animacao(pontoCampo.x, pontoCampo.y, pontoCidade.x, pontoCidade.y, "Frutas, Legumes e Outros", color(128, 0, 128)));  // Cor roxa
  }
}

// Classe para a animação das bolinhas
class Animacao {
  constructor(x1, y1, x2, y2, texto, cor) {
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
    this.texto = texto;
    this.cor = cor;
    this.t = 0; // Tempo da animação (0 a 1)
  }

  update() {
    this.t += 0.02; // Agora a animação está mais lenta (valor reduzido)
    if (this.t > 1) {
      this.t = 1; // Limitar a animação
    }
  }

  display() {
    let x = lerp(this.x1, this.x2, this.t); // Lerp para animar a transição
    let y = lerp(this.y1, this.y2, this.t);

    fill(this.cor);
    noStroke();
    ellipse(x, y, 30, 30);

    fill(0); // Cor preta para o texto
    textSize(14);
    textAlign(CENTER, CENTER);
    text(this.texto, x, y - 20); // Exibir o texto acima da bolinha
  }
}
